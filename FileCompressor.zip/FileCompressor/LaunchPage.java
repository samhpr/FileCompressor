import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class LaunchPage implements ActionListener {
	
	public static final int FRAME_SIZE_X = 800;
	public static final int FRAME_SIZE_Y = 800;
	
	
	JFrame frame = new JFrame();
	JButton button = new JButton("New Window");
	JLabel label = new JLabel("Hello World");
	
	LaunchPage()
	{
		
		button.setBounds(FRAME_SIZE_X / 2 - 100,FRAME_SIZE_Y / 2 - 200, 200, 200);
		button.setFocusable(false);
		button.addActionListener(this);
		
		label.setBounds(FRAME_SIZE_X / 2 - 50, FRAME_SIZE_Y / 2 - 50, 100, 100);
		label.setFont(new Font("MV Boli", Font.PLAIN, 50));
		//label.setSize(300, 300);
		
		//frame.add(button);
		frame.add(label);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(FRAME_SIZE_X, FRAME_SIZE_Y);
		frame.setLayout(null);
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == button)
		{	
			// action
		}
	}
}
